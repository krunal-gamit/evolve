import SubscriptionManagement from '@/components/SubscriptionManagement';

export default function SubscriptionsPage() {
  return <SubscriptionManagement />;
}