import MemberManagement from '@/components/MemberManagement';

export default function MembersPage() {
  return <MemberManagement />;
}