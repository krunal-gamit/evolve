import Reports from '@/components/Reports';

export default function ReportsPage() {
  return <Reports />;
}